<?php
require_once 'config.php';

// Initialize database connection
try {
    $db = new PDO('sqlite:' . DB_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get statistics
$stats = [
    'total' => $db->query("SELECT COUNT(*) FROM inmates")->fetchColumn(),
    'male' => $db->query("SELECT COUNT(*) FROM inmates WHERE sex = 'M'")->fetchColumn(),
    'female' => $db->query("SELECT COUNT(*) FROM inmates WHERE sex = 'F'")->fetchColumn(),
    'felonies' => $db->query("SELECT COUNT(DISTINCT inmate_id) FROM charges WHERE charge_type = 'Felony'")->fetchColumn(),
    'misdemeanors' => $db->query("SELECT COUNT(DISTINCT inmate_id) FROM charges WHERE charge_type = 'Misdemeanor'")->fetchColumn(),
    'last_update' => $db->query("SELECT MAX(scrape_time) FROM scrape_logs WHERE status = 'success'")->fetchColumn()
];

// Get filter parameters
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$query = "
    SELECT 
        i.*,
        GROUP_CONCAT(c.charge_description, '; ') as charges,
        GROUP_CONCAT(DISTINCT c.charge_type) as charge_types
    FROM inmates i
    LEFT JOIN charges c ON i.inmate_id = c.inmate_id
    WHERE 1=1
";

$params = [];

if ($search) {
    $query .= " AND (i.name LIKE ? OR c.charge_description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$query .= " GROUP BY i.id";

// Apply filters after grouping
$havingClauses = [];
if ($filter === 'felony') {
    $havingClauses[] = "charge_types LIKE '%Felony%'";
} elseif ($filter === 'misdemeanor') {
    $havingClauses[] = "charge_types LIKE '%Misdemeanor%'";
} elseif ($filter === 'male') {
    $query = str_replace('WHERE 1=1', 'WHERE i.sex = "M"', $query);
} elseif ($filter === 'female') {
    $query = str_replace('WHERE 1=1', 'WHERE i.sex = "F"', $query);
}

if (!empty($havingClauses)) {
    $query .= " HAVING " . implode(' AND ', $havingClauses);
}

$query .= " ORDER BY i.booking_date DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$inmates = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clayton County Jail Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 30px;
        }
        
        h1 {
            color: #333;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #666;
            font-size: 1.1em;
        }
        
        .last-update {
            color: #888;
            font-size: 0.9em;
            margin-top: 10px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .stat-card h3 {
            font-size: 0.9em;
            color: #666;
            text-transform: uppercase;
            margin-bottom: 10px;
            letter-spacing: 1px;
        }
        
        .stat-card .number {
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
        }
        
        .stat-card.male .number { color: #3b82f6; }
        .stat-card.female .number { color: #ec4899; }
        .stat-card.felony .number { color: #ef4444; }
        .stat-card.misdemeanor .number { color: #f59e0b; }
        
        .controls {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
        }
        
        .search-box {
            flex: 1;
            min-width: 250px;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1em;
            transition: border-color 0.3s;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .filter-tabs {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .filter-btn {
            padding: 10px 20px;
            border: none;
            background: #f3f4f6;
            color: #374151;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.95em;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
        }
        
        .filter-btn:hover {
            background: #e5e7eb;
        }
        
        .filter-btn.active {
            background: #667eea;
            color: white;
        }
        
        .refresh-btn {
            padding: 10px 25px;
            background: #10b981;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }
        
        .refresh-btn:hover {
            background: #059669;
        }
        
        .roulette-btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 700;
            font-size: 1.1em;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(245, 158, 11, 0.4);
            animation: pulse 2s infinite;
        }
        
        .roulette-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(245, 158, 11, 0.6);
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.85; }
        }
        
        .table-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85em;
            letter-spacing: 1px;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #f3f4f6;
        }
        
        tbody tr {
            transition: background 0.2s;
        }
        
        tbody tr:hover {
            background: #f9fafb;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
            margin-right: 5px;
            margin-bottom: 5px;
        }
        
        .badge-felony {
            background: #fee2e2;
            color: #dc2626;
        }
        
        .badge-misdemeanor {
            background: #fef3c7;
            color: #d97706;
        }
        
        .badge-male {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-female {
            background: #fce7f3;
            color: #be185d;
        }
        
        .charges-cell {
            max-width: 400px;
            font-size: 0.9em;
            line-height: 1.6;
        }
        
        .no-results {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        
        .no-results svg {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
            animation: fadeIn 0.3s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from { 
                transform: translateY(-50px);
                opacity: 0;
            }
            to { 
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 20px;
            width: 90%;
            max-width: 700px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: slideIn 0.4s;
            overflow: hidden;
        }
        
        .modal-header {
            background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
            color: white;
            padding: 30px;
            position: relative;
        }
        
        .modal-header h2 {
            margin: 0;
            font-size: 2em;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .modal-header .roulette-icon {
            font-size: 1.5em;
            animation: spin 2s linear;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .close {
            position: absolute;
            top: 20px;
            right: 25px;
            color: white;
            font-size: 35px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .close:hover {
            transform: scale(1.2);
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .inmate-info {
            background: #f9fafb;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 25px;
        }
        
        .inmate-info h3 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.5em;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-label {
            font-weight: 600;
            color: #666;
            font-size: 0.85em;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .info-value {
            font-size: 1.1em;
            color: #333;
            font-weight: 500;
        }
        
        .bond-amount {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3);
        }
        
        .bond-amount .label {
            font-size: 0.9em;
            opacity: 0.9;
            margin-bottom: 5px;
        }
        
        .bond-amount .amount {
            font-size: 2.5em;
            font-weight: bold;
        }
        
        .charges-list {
            margin-top: 15px;
        }
        
        .charges-list .info-label {
            margin-bottom: 10px;
        }
        
        .bond-instructions {
            background: #fff7ed;
            border-left: 4px solid #f59e0b;
            padding: 20px;
            border-radius: 10px;
        }
        
        .bond-instructions h4 {
            color: #f59e0b;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        
        .bond-instructions ol {
            padding-left: 20px;
            line-height: 1.8;
        }
        
        .bond-instructions li {
            margin-bottom: 10px;
        }
        
        .contact-info {
            background: #eff6ff;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .contact-info h4 {
            color: #3b82f6;
            margin-bottom: 15px;
        }
        
        .contact-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            font-size: 1.05em;
        }
        
        .contact-item strong {
            color: #1e40af;
        }
        
        @media (max-width: 768px) {
            h1 {
                font-size: 1.8em;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .controls {
                flex-direction: column;
            }
            
            .search-box {
                width: 100%;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                width: 95%;
                margin: 10% auto;
            }
            
            table {
                font-size: 0.9em;
            }
            
            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🏛️ Clayton County Jail Dashboard</h1>
            <p class="subtitle">Real-time inmate tracking and analytics</p>
            <?php if ($stats['last_update']): ?>
                <p class="last-update">Last updated: <?= date('F j, Y g:i A', strtotime($stats['last_update'])) ?></p>
            <?php endif; ?>
        </header>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Inmates</h3>
                <div class="number"><?= $stats['total'] ?></div>
            </div>
            
            <div class="stat-card male">
                <h3>Male</h3>
                <div class="number"><?= $stats['male'] ?></div>
            </div>
            
            <div class="stat-card female">
                <h3>Female</h3>
                <div class="number"><?= $stats['female'] ?></div>
            </div>
            
            <div class="stat-card felony">
                <h3>Felonies</h3>
                <div class="number"><?= $stats['felonies'] ?></div>
            </div>
            
            <div class="stat-card misdemeanor">
                <h3>Misdemeanors</h3>
                <div class="number"><?= $stats['misdemeanors'] ?></div>
            </div>
        </div>
        
        <div class="controls">
            <div class="search-box">
                <form method="GET" style="margin: 0;">
                    <input type="text" name="search" placeholder="🔍 Search by name or charge..." value="<?= htmlspecialchars($search) ?>">
                    <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                </form>
            </div>
            
            <div class="filter-tabs">
                <a href="?filter=all&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">All</a>
                <a href="?filter=felony&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'felony' ? 'active' : '' ?>">Felonies</a>
                <a href="?filter=misdemeanor&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'misdemeanor' ? 'active' : '' ?>">Misdemeanors</a>
                <a href="?filter=male&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'male' ? 'active' : '' ?>">Male</a>
                <a href="?filter=female&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'female' ? 'active' : '' ?>">Female</a>
            </div>
            
            <button class="roulette-btn" onclick="bondRoulette()">🎰 Bond Roulette!</button>
            <button class="refresh-btn" onclick="window.location.reload()">♻️ Refresh</button>
        </div>
        
        <div class="table-container">
            <?php if (count($inmates) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Sex</th>
                            <th>Race</th>
                            <th>Age</th>
                            <th>Booking Date</th>
                            <th>Charges</th>
                            <th>Bond</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inmates as $inmate): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($inmate['name']) ?></strong></td>
                                <td>
                                    <span class="badge badge-<?= strtolower($inmate['sex']) === 'm' ? 'male' : 'female' ?>">
                                        <?= $inmate['sex'] === 'M' ? 'Male' : 'Female' ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($inmate['race']) ?></td>
                                <td><?= htmlspecialchars($inmate['age']) ?></td>
                                <td><?= htmlspecialchars($inmate['booking_date']) ?></td>
                                <td class="charges-cell">
                                    <?php 
                                    $charges = explode('; ', $inmate['charges']);
                                    $chargeTypes = explode(',', $inmate['charge_types'] ?? '');
                                    foreach ($charges as $i => $charge):
                                        $type = $chargeTypes[$i] ?? 'Unknown';
                                        $badgeClass = strtolower($type) === 'felony' ? 'badge-felony' : 
                                                     (strtolower($type) === 'misdemeanor' ? 'badge-misdemeanor' : '');
                                    ?>
                                        <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars(trim($charge)) ?></span>
                                    <?php endforeach; ?>
                                </td>
                                <td><?= htmlspecialchars($inmate['bond_amount']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-results">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h2>No inmates found</h2>
                    <p>Try adjusting your search or filter criteria</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bond Roulette Modal -->
    <div id="bondModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><span class="roulette-icon">🎰</span> Bond Roulette Result</h2>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Content will be populated by JavaScript -->
            </div>
        </div>
    </div>

    <script>
        // Store inmates data for roulette
        const inmatesData = <?= json_encode($inmates) ?>;

        function bondRoulette() {
            if (inmatesData.length === 0) {
                alert('No inmates available for roulette!');
                return;
            }

            // Get random inmate
            const randomIndex = Math.floor(Math.random() * inmatesData.length);
            const inmate = inmatesData[randomIndex];

            // Build modal content
            const modalContent = `
                <div class="inmate-info">
                    <h3>👤 Inmate Information</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="info-label">Full Name</span>
                            <span class="info-value">${escapeHtml(inmate.name)}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Booking Date</span>
                            <span class="info-value">${escapeHtml(inmate.booking_date)}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Sex</span>
                            <span class="info-value">${inmate.sex === 'M' ? 'Male' : 'Female'}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Race</span>
                            <span class="info-value">${escapeHtml(inmate.race)}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Age</span>
                            <span class="info-value">${escapeHtml(inmate.age)}</span>
                        </div>
                    </div>
                    
                    <div class="bond-amount">
                        <div class="label">💰 BOND AMOUNT</div>
                        <div class="amount">${escapeHtml(inmate.bond_amount)}</div>
                    </div>
                    
                    <div class="charges-list">
                        <span class="info-label">⚖️ Charges</span>
                        <div class="charges-cell">
                            ${inmate.charges ? inmate.charges.split('; ').map(charge => 
                                `<span class="badge badge-felony">${escapeHtml(charge)}</span>`
                            ).join('') : 'No charges listed'}
                        </div>
                    </div>
                </div>

                <div class="bond-instructions">
                    <h4>📋 How to Post Bond in Clayton County</h4>
                    <ol>
                        <li><strong>Contact a Licensed Bail Bondsman:</strong> You'll typically need to pay 10-15% of the total bond amount to a bondsman.</li>
                        <li><strong>Provide Required Information:</strong> Bring the inmate's full name, booking number, charges, and bond amount.</li>
                        <li><strong>Sign the Agreement:</strong> You (the indemnitor) will sign a contract agreeing to ensure the defendant appears in court.</li>
                        <li><strong>Pay the Premium:</strong> Pay the non-refundable fee (typically 10-15% of bond amount) plus any additional fees.</li>
                        <li><strong>Wait for Release:</strong> Processing can take 2-8 hours depending on jail capacity.</li>
                    </ol>
                </div>

                <div class="contact-info">
                    <h4>📞 Clayton County Jail Contact Information</h4>
                    <div class="contact-item">
                        <strong>Address:</strong> 9157 Tara Blvd, Jonesboro, GA 30236
                    </div>
                    <div class="contact-item">
                        <strong>Phone:</strong> (770) 477-4479
                    </div>
                    <div class="contact-item">
                        <strong>Inmate Info:</strong> (770) 477-3747
                    </div>
                    <div class="contact-item">
                        <strong>Visiting Hours:</strong> Sat-Sun 9:00 AM - 5:00 PM
                    </div>
                </div>
            `;

            document.getElementById('modalBody').innerHTML = modalContent;
            document.getElementById('bondModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('bondModal').style.display = 'none';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('bondModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeModal();
            }
        });
    </script>
</body>
</html>