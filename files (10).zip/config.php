<?php
// Database Configuration
define('DB_PATH', __DIR__ . '/jail_data.db');

// Scraper Configuration
define('SCRAPE_URL', 'https://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj210r.pgm?days=02&rtype=F');
define('SCRAPE_INTERVAL', 3600); // 1 hour in seconds
define('SCRAPE_DURATION', 172800); // 48 hours in seconds
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
define('TIMEOUT', 30);

// Logging
define('LOG_FILE', __DIR__ . '/scraper.log');

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', LOG_FILE);

// Timezone
date_default_timezone_set('America/New_York');
?>